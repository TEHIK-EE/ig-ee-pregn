# Home - PREGN - Raseduse fakti tuvastamine v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/pregn/ImplementationGuide/ee.fhir.pregn | *Version*:0.1.0 |
| Draft as of 2026-02-12 | *Computable Name*:PREGN |

# Raseduse fakti tuvastamine (PREGN)

### Üldine informatsioon

Raseduse fakti tuvastamise teenus (PREGN) loob ja uuendab rasedusega seotud fakte ja sündmusi. Teenuse kaudu saab pärida patsiendi aktiivseid rasedusi. Päring tagastab FHIR Condition ressursi.

### Arendusvahendid ja lähtekood

* PREGN-i juurutusjuhendi lähtekood on leitav [GitHubis](https://github.com/TEHIK-EE/ig-ee-pregn).
* Antud sait on välja töötatud [FHIR Shorthand](https://build.fhir.org/ig/HL7/fhir-shorthand) abiga.
* Juurutusjuhendi avaldamiseks on kasutatud [FHIR IG Auto-Builderit](https://github.com/FHIR/auto-ig-builder) ja Github Pages.

